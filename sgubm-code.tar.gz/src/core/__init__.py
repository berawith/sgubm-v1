"""
SGUBM-V1 Core Package
Núcleo del sistema - Entidades e Interfaces
"""
